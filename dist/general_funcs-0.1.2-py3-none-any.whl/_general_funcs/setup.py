from setuptools import find_packages, setup

setup(
    name="general_funcs_utils",
    packages=find_packages('src'),
    package_dir={'': 'src'},
    setup_requires=["wheel"],
    description="",
    author="",
    version="0.1.2"
)